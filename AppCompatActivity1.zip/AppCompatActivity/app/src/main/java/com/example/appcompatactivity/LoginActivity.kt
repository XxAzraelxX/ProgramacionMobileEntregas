package com.example.appcompatactivity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.*
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var rememberCheckBox: CheckBox
    private val PREFS_NAME = "login_prefs"
    private val KEY_EMAIL = "email"
    private val KEY_REMEMBER = "remember"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val sharedPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        // Inicializar vistas
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        rememberCheckBox = findViewById(R.id.rememberCheckBox)

        // Cargar datos guardados (si los hay)
        val savedEmail = sharedPrefs.getString(KEY_EMAIL, "")
        val isRemembered = sharedPrefs.getBoolean(KEY_REMEMBER, false)

        // Deshabilitar botón por defecto
        loginButton.isEnabled = false


        // Validación de campos en tiempo real
        val textWatcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val email = emailEditText.text.toString().trim()
                val password = passwordEditText.text.toString().trim()
                loginButton.isEnabled = email.isNotEmpty() && password.isNotEmpty()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }
        emailEditText.setText(savedEmail)
        rememberCheckBox.isChecked = isRemembered

        emailEditText.addTextChangedListener(textWatcher)
        passwordEditText.addTextChangedListener(textWatcher)

        // Acción del botón
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()
            val remember = rememberCheckBox.isChecked

            // Validación simple
            // Validación simple
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Validación simulada (usuario ficticio)
            if (email != "usuario@demo.com" || password != "1234") {
                Toast.makeText(this, "Correo o contraseña incorrectos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }


            // Guardar en SharedPreferences si "Recordarme" está activado
            val editor = sharedPrefs.edit()
            if (remember) {
                editor.putString(KEY_EMAIL, email)
                editor.putBoolean(KEY_REMEMBER, true)
            } else {
                editor.remove(KEY_EMAIL)
                editor.putBoolean(KEY_REMEMBER, false)
            }
            editor.apply()

            // Aquí puedes navegar a la siguiente pantalla
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("email", email)
            startActivity(intent)
            finish()
        }
    }
}
